#ifndef DEFINE_H
#define DEFINE_H


#define ID			"111111110"		//your id
#define PASSWORD	"123456"		//your password
#define SERVER_IP	"127.0.0.1"		//server ip
#define	SERVER_PORT	10087			//server port

		



#endif
